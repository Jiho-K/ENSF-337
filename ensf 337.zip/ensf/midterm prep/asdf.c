#include <stdio.h>
#include <stdlib.h>

double* reduce_size(double* x, int N, int M);

int main() {
	double asdf[] = {1, 3, 2, 4, 41.13};
	double* a = reduce_size(asdf, 5, 3);
	
	for(int i = 0; i < 4; i++){
		printf("%.2f\n", a[i]);
	}
	
	return 1;
}

double* reduce_size(double* x, int N, int M){
	double* temp = x;
	x = malloc(M * sizeof(double));
	for(int i  = 0; i < M; i++){
		x[i] = temp[i];
	}
	//free(temp);
	return x;
}