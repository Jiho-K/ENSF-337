//  ENSF 337 - Fall 2019 Lab  Exercise A
//  M. Moussavi
//  lab6exe_A.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lab6exe_A.h"

char str [] = "foo";

void goodcopy(String *dest, const String *src)
{
    dest->text = (char*)malloc(strlen(src->text) + 1);
	//now has 5 bits (including \0)
    
    if(dest -> text == NULL) {
        fprintf(stderr, "Memory Not Available...");
        exit(1);
    }
    
    dest->length = src -> length;
	//dest-> length now has value of 3
    
    int i;
    for(i = 0; i < src -> length; i++)
        dest->text[i] = src -> text[i];
    
    dest->text[i] = '\0';
}

void badcopy (String *dest, const String *src)
{
    *dest = *src;
    // point one
	printf("\n\n%s\n\n", dest->text);
}


int main(void)
{
    String s1 = {str, (int) strlen(str)};
	//s1 now has "foo" and 3
    
    String *s2 = (String*) malloc(sizeof(String));
    //s2 points to heap where it has memory allocated for String and int value
	printf("%i\n", sizeof(String));
	
    if(s2 == NULL) {
        fprintf(stderr, "Memory Not Available...");
        exit(1);
    }
    
    goodcopy(s2, &s1);
    
    s1.text = (char*) malloc(strlen("mars") +1);
    
    if(s1.text == NULL) {
        fprintf(stderr, "Memory Not Available...");
        exit(1);
    }
	
	
    
    strcpy(s1.text, "mars");
	
    s1.length = 4;
    
    badcopy(s2, &s1);
	printf("%s", s2->text);
	printf("%i", s2->length);
	

    
    return 0;
}

