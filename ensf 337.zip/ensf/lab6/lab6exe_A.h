//  ENSF 337 - Fall 2019 Lab 6 Exercise A
//  M. Moussavi
//  lab6exe_A.h


#ifndef lab6ExA_h
#define lab6ExA_h

typedef struct String {
    char* text;
    int length;
} String;


#endif /* lab6ExA_h */
