
// node.h

#include "node.h"

void Node::set_next(Node* n) {
    next = n;
    // POINT N -  WHEN REACHED FOR THE FIRST TIME
}
