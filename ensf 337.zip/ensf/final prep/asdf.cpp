using namespace std;
#include <iostream>

void fun(int** x,int m)
{
	*x = new int [m];
	
}

int main(){
	int *p;
	p = new int[sizeof(int)];
	*p = 222;
	*(p + 1) = 100;
	fun(&p, 4);
	p[1] = 579;
	// point one
	for(int i = 0; i<4; i++)
		cout<<p << " ";
	return 0;
}