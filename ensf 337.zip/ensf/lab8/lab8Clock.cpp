#include "lab8Clock.h"


void set_hour(int n);
		void set_minute(int n);
		void set_second(int n);
		

void Clock::set_hour(int n){
	if(n < 24 && n >= 0){
		hour = n;
	}
}

void Clock::set_minute(int n){
	if(n < 60 && n >= 0){
		minute = n;
	}
}

void Clock::set_second(int n){
	if(n < 60 && n >= 0){
		second = n;
	}
}

int Clock::hms_to_sec(){
	return(hour*3600 + minute*60 + second);
}

void Clock::sec_to_hms(int n){
	hour = n/3600;
	minute = (n%3600)/60;
	second = n%60;
	
	while(second<0){
		second+=60;
		minute--;
	}
	while(second>=60){
		second-=60;
		minute++;
	}
	while(minute<0){
		minute+=60;
		hour--;
	}
	
	while(minute>=60){
		second-=60;
		hour++;
	}
	while(hour >= 24){
		hour-=24;
	}
	while(hour < 0){
		hour += 24;
	}
}

Clock::Clock(){
	hour = 0, minute = 0, second = 0;
}

Clock::Clock(int n){
	if(n >= 0)
		sec_to_hms(n);
	else
		hour = 0, minute = 0, second = 0;
}

Clock::Clock(int h, int m, int s){
	if(h < 24 && h >= 0 && m < 60 && m >= 0 && s >= 0 && s < 60)
		hour = h, minute = m, second = s;
	else
		hour = 0, minute = 0, second = 0;
	
}

void Clock::increment(){
	sec_to_hms(hms_to_sec()+1);
}

void Clock::decrement(){
	sec_to_hms(hms_to_sec()-1);
}

void Clock::add_seconds(int n){
	sec_to_hms(hms_to_sec() + n);
}

