//Written by Jiho Kim


struct ListItem{
	int year;
	double flow;
};

struct Node {
	ListItem item;
	Node *next;
};

class FlowList{
	public:
	FlowList();
	ListItem getItem();
	void setItem(const ListItem& source);
	Node* getNode();
	void setNode(const Node* source);
	
	
	private:
	Node* node;
	
};