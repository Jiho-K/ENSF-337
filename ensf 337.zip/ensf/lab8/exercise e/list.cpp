#include <iostream>
using namespace std;
#include "list.h"


	
ListItem FlowList:: getItem(){
	return node->item;
}

void FlowList:: setItem(const ListItem& source){
	node->item = source;
	return;
}

FlowList::FlowList(){
	node = 0;
}

Node* FlowList:: getNode(){
	return node;
}

void FlowList:: setNode(const Node* source){
	if(source == NULL){
		node = NULL;
		return;
	}
	
	Node* newNode = new Node;
	Node* placeHolder = newNode;
	
	Node* source_placeHolder = (Node*)source;
	
	
	
	while(source_placeHolder != NULL){
		placeHolder->item = source_placeHolder->item;
		source_placeHolder = source_placeHolder->next;
		if(source_placeHolder != NULL){
			placeHolder->next = new Node;
			placeHolder = placeHolder->next;
		}
		else{
			placeHolder->next = NULL;
		}
	}
	node = newNode;
}
