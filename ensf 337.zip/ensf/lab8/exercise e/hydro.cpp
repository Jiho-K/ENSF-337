#include <iostream>
using namespace std;
#include "hydro.h"
#include <fstream>
#define underline "\033[4m"
#define notUnderline "\033[0m"

int main(){
	FlowList fl;
	displayHeader();
	pressEnter();
	int numRecords = readData(fl);
	int quit = 0;
	
	while(1)
	{
		switch(menu()){
			case 1:
				display(fl, numRecords);
				break;
			case 2:
				addData(fl, numRecords);
				pressEnter();
				break;
			case 3:
				saveData(fl);
				pressEnter();
				break;
			case 4:
				removeData(fl, numRecords);
				pressEnter();
				break;
			case 5:	
				cout<< "\nProgram terminated successfully.\n\n";
				quit = 1;
				break;
			default:
				cout<< "\n Not a valid input.\n";
				pressEnter();
				
		}
		if(quit == 1) 
			break;
		
	}

	return 0;
}

void displayHeader(){
	cout<< "Program: Flow Studies - Fall 2019\nVersion: 1.0\nLab Section: B01\nProduced by: Jiho Kim\n";
	//cout<< "\n<<< Press Enter to Continue>>>>";
}

int readData(ListItem a){
	return 0;
}

int a = 0;
void pressEnter(){
	cout<< "\n<<< Press Enter to Continue>>>>\n";
	if(a != 0)
		cin.get();
	a++;
	cin.get();
}

int readData(FlowList& outputList){
	int counter = 0;
	ifstream scannerIn;
	scannerIn.open("flow.txt");
	
	if(!scannerIn){
		cout<<"flow.txt not found";
		exit(1);
	}
	
	int year;
	double flow_data;
	
	while(!scannerIn.eof()){
		scannerIn >> year >> flow_data;
		counter++;
		
		Node*  newNode = new Node;
		newNode->item.year = year;
		newNode->item.flow = flow_data;
		
		if(outputList.getNode() == 0){
			newNode->next = NULL;
			outputList.setNode(newNode);
		} else if(outputList.getNode()->item.flow > flow_data){
			
			newNode->next = outputList.getNode();
			outputList.setNode(newNode);
			
		} else{
			
			Node *before = outputList.getNode();
			while(before->next != 0 && flow_data > before->next->item.flow) {
				before = before->next;
			}
			
			newNode->next = before->next;
			before->next = newNode;
		}
		
	}
	scannerIn.close();
	return counter;
}


int menu(){
	cout<<"Please select on the following operations\n\t1.  Display flow list, average and median\n\t";
	cout<<"2.  Add data.\n\t3.  Save data into the file\n\t4.  Remove data\n\t";
	cout<<"5.  Quit\n\tEnter your choice (1, 2, 3, 4, or 5)\n\t";
	int a;
	cin >> a;
	return a;
}


double median(const FlowList& fl, int n){
	Node* placeHolder = ((FlowList)fl).getNode();
	double median = 0;
	
	//if even
	if(n%2 == 0){
		for(int i = 0; i <= n/2; i++){
			if(i == (n/2-1) || i == (n/2))
				median+=placeHolder->item.flow;
			
			placeHolder = placeHolder->next;
		}
		median /= 2;
	}else{
		for(int i = 0; i <= n/2; i++){
			if(i == (n/2))
				median = placeHolder->item.flow;
			
			placeHolder = placeHolder->next;
		}
	}
	return median;
}

double average(int total, int n){
	//please note that I purposely have this total as a parameter because there is no point
	//in repeating what I do in display() just to get the total. This would be a waste of
	//time and resources.
	return (total/n);
}


void display(const FlowList& fl, int n){
	cout<<"now displaying year and flow\n\n";
	cout<<underline<<"Year\tFlow (in billions of cubic meters)\n"<<notUnderline;
	Node* placeHolder = ((FlowList)fl).getNode();
	double total = 0;
	
	for(int i = 0; i < n; i++){
		cout<<placeHolder->item.year << "\t" << placeHolder->item.flow << "\n";
		
		total+=placeHolder->item.flow;
		placeHolder = placeHolder->next;
	}
	
	
	cout<<"\nThe annual average of the flow is: " << (average(total, n)) << " millions cubic meter\n";
	cout<<"The median flow is: " << (median(fl, n)) << " millions cubic meter.\n\n";
}


void addData(FlowList& outputList, int& a){
	int year;
	double flow;

	cout<<"Please enter a year: ";
	cin>> year;	
	
	cout<<"Please enter the flow: ";
	cin>>flow;
	
	cout<<"\n";
	
	Node*  newNode = new Node;
	newNode->item.year = year;
	newNode->item.flow = flow;
	
	Node* placeHolder = outputList.getNode();
	while(placeHolder!= NULL){
		if(placeHolder->item.year == year){
			cout<<"Error: Duplicate Data.\n";
			return;
		}
		placeHolder = placeHolder->next;
	}
	
	if(outputList.getNode() == 0){
		newNode->next = NULL;
		outputList.setNode(newNode);
	}else if(outputList.getNode()->item.flow > flow){
		newNode->next = outputList.getNode();
		outputList.setNode(newNode);
	}else{
		Node *before = outputList.getNode();
		while(before->next != 0 && flow > before->next->item.flow) {
			before = before->next;
		}
		
		newNode->next = before->next;
		before->next = newNode;
	}
	cout<<"New record inserted successfully";
	a++;
}

void removeData(FlowList& outputList, int& a){
	cout<<"Please enter the year that you want to remove: ";
	int year;
	cin>> year;
	
	Node* placeHolder = outputList.getNode();
	if(placeHolder->item.year == year){
		//when first value is the one that needs to be deleted:
		outputList.setNode(placeHolder->next);
		cout<<"Record was successfully removed.\n";
		a--;
		return;
	}
	while(placeHolder->next!= NULL){
		if(placeHolder->next->item.year == year){
			placeHolder->next = placeHolder->next->next;
			cout<<"Record was successfully removed.\n";
			a--;
			return;
		}
		placeHolder = placeHolder->next;
	}
	
	cout<<"Error: No such data.\n";
	return;
}

void saveData(const FlowList& inputList){
	ofstream scannerOut;
	scannerOut.open("flow.txt");
	
	if(!scannerOut){
		cout<<"flow.txt not found";
		exit(1);
	}
	
	Node* placeHolder = ((FlowList)inputList).getNode();
	while(placeHolder != NULL){
		scannerOut << placeHolder->item.year << "\t" << placeHolder->item.flow << "\n";
		placeHolder = placeHolder->next;
	}
	cout<<"Data are saved into the file.";
	scannerOut.close();
}