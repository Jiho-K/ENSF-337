#include "list.h"


void displayHeader();
int readData(ListItem a);
void pressEnter();
int readData(FlowList& outputList);
int menu();
double median(const FlowList& fl, int n);
double average(int total, int n);
void display(const FlowList& fl, int n);
void addData(FlowList& outputList, int& a);
void removeData(FlowList& outputList, int& a);
void saveData(const FlowList& inputList);
