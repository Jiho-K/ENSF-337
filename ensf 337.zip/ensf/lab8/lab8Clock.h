class Clock
{
	public:
		int get_hour() const {return hour;}
		int get_minute() const {return minute;}
		int get_second() const {return second;}
		
		void set_hour(int n);
		void set_minute(int n);
		void set_second(int n);
		
		void increment();
		void decrement();
		void add_seconds(int n);
		
		Clock();
		Clock(int n);
		Clock(int h, int m, int s);
		
	private:
		int hms_to_sec();
		void sec_to_hms(int n);
	
		
	
	int second, minute, hour;
};